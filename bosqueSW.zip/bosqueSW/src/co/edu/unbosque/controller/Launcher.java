package co.edu.unbosque.controller;

public class Launcher {

	public static void main(String[] args) {
		BosqueSW c = new BosqueSW();
	}
}
