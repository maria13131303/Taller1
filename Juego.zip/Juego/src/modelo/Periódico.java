package modelo;

public class Peri�dico {

}
