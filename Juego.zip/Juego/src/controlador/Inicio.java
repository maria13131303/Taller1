package controlador;

import vista.MapaDeJuego;

public class Inicio {
	public static void main(String[] args) {
			MapaDeJuego mj = new MapaDeJuego();
	}
}
