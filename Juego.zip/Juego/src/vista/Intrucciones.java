package vista;

import javax.swing.JFrame;

public class Intrucciones extends JFrame{
	Intrucciones(){
		
	}
}
